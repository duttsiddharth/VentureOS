import { createClient } from '@supabase/supabase-js'
import type { UserProfile, Plan, PLAN_LIMITS, AgentOutputs } from '@/types'

// ── Client (browser) ────────────────────────────────────
export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

// ── Admin client (server only — never expose to browser) ─
export function getAdminClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  )
}

// ── User helpers ─────────────────────────────────────────

export async function getUserByEmail(email: string): Promise<UserProfile | null> {
  const db = getAdminClient()
  const { data, error } = await db
    .from('users')
    .select('*')
    .eq('email', email)
    .single()
  if (error) return null
  return data as UserProfile
}

export async function upsertUser(params: {
  email: string
  name?: string | null
  image?: string | null
}): Promise<UserProfile> {
  const db = getAdminClient()
  const { data, error } = await db
    .from('users')
    .upsert({ email: params.email, name: params.name, image: params.image }, { onConflict: 'email' })
    .select()
    .single()
  if (error) throw error
  return data as UserProfile
}

export async function updateUserPlan(
  email: string,
  plan: Plan,
  stripeCustomerId?: string
): Promise<void> {
  const db = getAdminClient()
  const PLAN_LIMITS: Record<Plan, number> = {
    free: 1,
    starter: 10,
    pro: 999999,
    agency: 999999,
  }
  const updates: Record<string, unknown> = { plan, analyses_limit: PLAN_LIMITS[plan] }
  if (stripeCustomerId) updates.stripe_customer_id = stripeCustomerId
  await db.from('users').update(updates).eq('email', email)
}

export async function incrementAnalysesUsed(email: string): Promise<void> {
  const db = getAdminClient()
  await db.rpc('increment_analyses_used', { user_email: email })
  // Fallback if RPC not set up:
  const user = await getUserByEmail(email)
  if (user) {
    await db.from('users').update({ analyses_used: user.analyses_used + 1 }).eq('email', email)
  }
}

export async function canRunAnalysis(email: string): Promise<{ allowed: boolean; reason?: string }> {
  const user = await getUserByEmail(email)
  if (!user) return { allowed: false, reason: 'User not found' }
  if (user.analyses_used >= user.analyses_limit) {
    return {
      allowed: false,
      reason: `You've used all ${user.analyses_limit} analyses on your ${user.plan} plan. Upgrade to continue.`,
    }
  }
  return { allowed: true }
}

// ── Analysis helpers ─────────────────────────────────────

export async function createAnalysis(params: {
  userId: string
  idea: string
}): Promise<string> {
  const db = getAdminClient()
  const { data, error } = await db
    .from('analyses')
    .insert({ user_id: params.userId, idea: params.idea, status: 'running' })
    .select('id')
    .single()
  if (error) throw error
  return data.id
}

export async function updateAnalysis(
  id: string,
  params: {
    agent_outputs?: AgentOutputs
    synthesis?: string
    status?: string
  }
): Promise<void> {
  const db = getAdminClient()
  await db.from('analyses').update(params).eq('id', id)
}

export async function getAnalysesByUser(userId: string, limit = 20) {
  const db = getAdminClient()
  const { data } = await db
    .from('analyses')
    .select('id, idea, synthesis, status, created_at')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit)
  return data || []
}

export async function getAnalysisById(id: string) {
  const db = getAdminClient()
  const { data } = await db.from('analyses').select('*').eq('id', id).single()
  return data
}

// ── Subscription helpers ─────────────────────────────────

export async function upsertSubscription(params: {
  userId: string
  stripeSubscriptionId: string
  stripePriceId: string
  plan: Plan
  status: string
  currentPeriodEnd: Date
  cancelAtPeriodEnd: boolean
}): Promise<void> {
  const db = getAdminClient()
  await db.from('subscriptions').upsert({
    user_id: params.userId,
    stripe_subscription_id: params.stripeSubscriptionId,
    stripe_price_id: params.stripePriceId,
    plan: params.plan,
    status: params.status,
    current_period_end: params.currentPeriodEnd.toISOString(),
    cancel_at_period_end: params.cancelAtPeriodEnd,
  }, { onConflict: 'stripe_subscription_id' })
}
