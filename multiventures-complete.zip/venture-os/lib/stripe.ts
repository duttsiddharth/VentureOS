import Stripe from 'stripe'
import type { PricingTier } from '@/types'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
})

// ── Pricing Tiers ────────────────────────────────────────
// Update priceId values with your actual Stripe Price IDs
export const PRICING_TIERS: PricingTier[] = [
  {
    name: 'Starter',
    plan: 'starter',
    price: 29,
    priceId: process.env.STRIPE_PRICE_STARTER || '',
    analyses: '10 analyses / month',
    features: [
      '10 venture analyses per month',
      'All 6 AI agents',
      'Master synthesis report',
      'Export to text/PDF',
      'Analysis history (30 days)',
      'Email support',
    ],
    cta: 'Get Started',
    highlighted: false,
  },
  {
    name: 'Pro',
    plan: 'pro',
    price: 79,
    priceId: process.env.STRIPE_PRICE_PRO || '',
    analyses: 'Unlimited analyses',
    features: [
      'Unlimited venture analyses',
      'All 6 AI agents',
      'Master synthesis report',
      'Export to text/PDF',
      'Full analysis history',
      'Priority support',
      'API access (coming soon)',
      'Custom agent prompts (coming soon)',
    ],
    cta: 'Go Pro',
    highlighted: true,
  },
  {
    name: 'Agency',
    plan: 'agency',
    price: 299,
    priceId: process.env.STRIPE_PRICE_AGENCY || '',
    analyses: 'Unlimited + white-label',
    features: [
      'Everything in Pro',
      'White-label reports with your brand',
      'Client management dashboard',
      'Bulk analysis (10 ideas at once)',
      'API access + webhooks',
      'Dedicated Slack channel',
      'Custom agent training',
      'Invoice billing available',
    ],
    cta: 'Contact Sales',
    highlighted: false,
  },
]

// ── Price ID → Plan mapping ──────────────────────────────
export function planFromPriceId(priceId: string): string {
  const tier = PRICING_TIERS.find(t => t.priceId === priceId)
  return tier?.plan || 'free'
}

// ── Create Stripe customer ───────────────────────────────
export async function createOrRetrieveCustomer(params: {
  email: string
  name?: string | null
  stripeCustomerId?: string | null
}): Promise<string> {
  if (params.stripeCustomerId) {
    // Verify customer still exists
    try {
      const customer = await stripe.customers.retrieve(params.stripeCustomerId)
      if (!customer.deleted) return params.stripeCustomerId
    } catch {}
  }
  // Create new customer
  const customer = await stripe.customers.create({
    email: params.email,
    name: params.name || undefined,
    metadata: { source: 'multiventures' },
  })
  return customer.id
}

// ── Create checkout session ──────────────────────────────
export async function createCheckoutSession(params: {
  customerId: string
  priceId: string
  userId: string
  userEmail: string
  successUrl: string
  cancelUrl: string
}): Promise<string> {
  const session = await stripe.checkout.sessions.create({
    customer: params.customerId,
    mode: 'subscription',
    payment_method_types: ['card'],
    line_items: [{ price: params.priceId, quantity: 1 }],
    success_url: params.successUrl,
    cancel_url: params.cancelUrl,
    metadata: { userId: params.userId, userEmail: params.userEmail },
    subscription_data: {
      metadata: { userId: params.userId, userEmail: params.userEmail },
    },
    allow_promotion_codes: true,
  })
  return session.url!
}

// ── Create billing portal session ───────────────────────
export async function createBillingPortalSession(params: {
  customerId: string
  returnUrl: string
}): Promise<string> {
  const session = await stripe.billingPortal.sessions.create({
    customer: params.customerId,
    return_url: params.returnUrl,
  })
  return session.url
}
