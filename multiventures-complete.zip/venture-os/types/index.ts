// ── Plan Types ──────────────────────────────────────────
export type Plan = 'free' | 'starter' | 'pro' | 'agency'

export const PLAN_LIMITS: Record<Plan, number> = {
  free: 1,
  starter: 10,
  pro: 999999,
  agency: 999999,
}

export const PLAN_LABELS: Record<Plan, string> = {
  free: 'Free',
  starter: 'Starter',
  pro: 'Pro',
  agency: 'Agency',
}

// ── Agent Types ─────────────────────────────────────────
export type AgentId = 'market' | 'strategy' | 'finance' | 'growth' | 'ops' | 'risk'

export interface Agent {
  id: AgentId
  label: string
  abbr: string
  desc: string
  border: string
  bg: string
  text: string
  prompt: string
}

// ── Analysis Types ───────────────────────────────────────
export type AnalysisStatus = 'pending' | 'running' | 'complete' | 'error'

export interface AgentOutputs {
  market?: string
  strategy?: string
  finance?: string
  growth?: string
  ops?: string
  risk?: string
}

export interface Analysis {
  id: string
  user_id: string
  idea: string
  agent_outputs: AgentOutputs | null
  synthesis: string | null
  status: AnalysisStatus
  created_at: string
}

// ── User Types ───────────────────────────────────────────
export interface UserProfile {
  id: string
  email: string
  name: string | null
  image: string | null
  stripe_customer_id: string | null
  plan: Plan
  analyses_used: number
  analyses_limit: number
  created_at: string
}

// ── Pricing Types ────────────────────────────────────────
export interface PricingTier {
  name: string
  plan: Plan
  price: number
  priceId: string
  analyses: string
  features: string[]
  cta: string
  highlighted: boolean
}
