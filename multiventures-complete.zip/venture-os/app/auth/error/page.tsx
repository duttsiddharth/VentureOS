import Link from 'next/link'

export default function AuthErrorPage() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center px-6 text-[#f0ede8]">
      <div className="text-center">
        <div className="w-12 h-12 rounded-xl bg-red-500/20 flex items-center justify-center mx-auto mb-4 text-red-400 text-xl">!</div>
        <h1 className="text-xl font-bold mb-2">Authentication Error</h1>
        <p className="text-white/50 text-sm mb-6">Something went wrong during sign-in. Please try again.</p>
        <Link href="/auth/signin" className="btn-gradient px-6 py-3 rounded-xl text-sm font-semibold inline-block">
          Try Again
        </Link>
      </div>
    </div>
  )
}
