import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { Providers } from './providers'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'MultiVentures — AI-Powered Business Intelligence',
  description: "MultiVentures runs your business idea through 6 specialized AI agents — Market, Strategy, Finance, Growth, Ops, and Risk — then synthesizes a definitive venture blueprint — Market, Strategy, Finance, Growth, Ops, Risk — then synthesizes a definitive venture blueprint.",
  keywords: ['business analysis', 'AI startup advisor', 'venture intelligence', 'business idea validation'],
  openGraph: {
    title: 'MultiVentures — AI-Powered Business Intelligence',
    description: 'Refract your idea through 6 AI agents in minutes. 1 comprehensive venture report.',
    type: 'website',
    images: [{ url: '/og-image.png', width: 1200, height: 630 }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MultiVentures — 6 AI Agents. One Venture Blueprint.',
    description: 'Market · Strategy · Finance · Growth · Ops · Risk — all in one report.',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
