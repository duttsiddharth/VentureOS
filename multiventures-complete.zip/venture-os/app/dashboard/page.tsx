'use client'
import { useState, useRef, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import Link from 'next/link'
import Navbar from '@/components/Navbar'
import { AGENTS } from '@/lib/agents'
import type { AgentId, AgentOutputs } from '@/types'

type Phase = 'idle' | 'running' | 'done'
type SSEEvent = { type: string; agentId?: AgentId; output?: string; synthesis?: string; message?: string; analysisId?: string }

const AGENT_COLORS: Record<AgentId, { border: string; bg: string; text: string }> = {
  market:   { border: '#378ADD', bg: '#E6F1FB11', text: '#5BA3E8' },
  strategy: { border: '#7F77DD', bg: '#7F77DD11', text: '#A09DE8' },
  finance:  { border: '#639922', bg: '#63992211', text: '#82C42D' },
  growth:   { border: '#BA7517', bg: '#BA751711', text: '#E09020' },
  ops:      { border: '#D85A30', bg: '#D85A3011', text: '#E8784D' },
  risk:     { border: '#E24B4A', bg: '#E24B4A11', text: '#E87070' },
}

export default function DashboardPage() {
  const { data: session } = useSession()
  const user = session?.user as any

  const [idea, setIdea]               = useState('')
  const [phase, setPhase]             = useState<Phase>('idle')
  const [activeAgentId, setActiveAgentId] = useState<AgentId | null>(null)
  const [agentOutputs, setAgentOutputs]   = useState<AgentOutputs>({})
  const [synthesis, setSynthesis]     = useState('')
  const [selectedAgent, setSelectedAgent] = useState<AgentId | null>(null)
  const [analysisId, setAnalysisId]   = useState<string | null>(null)
  const [error, setError]             = useState('')
  const [showUpgrade, setShowUpgrade] = useState(false)
  const readerRef = useRef<ReadableStreamDefaultReader | null>(null)

  const plan: string      = user?.plan || 'free'
  const used: number      = user?.analysesUsed || 0
  const limit: number     = user?.analysesLimit || 1
  const canRun = used < limit

  const runAnalysis = useCallback(async () => {
    if (!idea.trim() || phase === 'running') return
    setPhase('running')
    setAgentOutputs({})
    setSynthesis('')
    setSelectedAgent(null)
    setAnalysisId(null)
    setError('')
    setShowUpgrade(false)

    const res = await fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ idea }),
    })

    if (res.status === 402) {
      const data = await res.json()
      setError(data.error)
      setShowUpgrade(true)
      setPhase('idle')
      return
    }
    if (!res.ok || !res.body) {
      const data = await res.json().catch(() => ({}))
      setError(data.error || 'Something went wrong. Please try again.')
      setPhase('idle')
      return
    }

    const reader = res.body.getReader()
    readerRef.current = reader
    const decoder = new TextDecoder()
    let buffer = ''

    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      buffer += decoder.decode(value, { stream: true })
      const lines = buffer.split('\n')
      buffer = lines.pop() || ''

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue
        try {
          const event: SSEEvent = JSON.parse(line.slice(6))

          if (event.type === 'agent_start' && event.agentId) {
            setActiveAgentId(event.agentId)
          }
          if (event.type === 'agent_complete' && event.agentId && event.output) {
            setAgentOutputs(prev => ({ ...prev, [event.agentId!]: event.output! }))
            setActiveAgentId(null)
            setSelectedAgent(event.agentId)
          }
          if (event.type === 'synthesis_start') {
            setActiveAgentId(null)
          }
          if (event.type === 'complete') {
            setSynthesis(event.synthesis || '')
            setAnalysisId(event.analysisId || null)
            setPhase('done')
          }
          if (event.type === 'error') {
            setError(event.message || 'Analysis failed.')
            setPhase('idle')
          }
        } catch {}
      }
    }
  }, [idea, phase])

  const completedCount = Object.keys(agentOutputs).length
  const isSynthesizing = phase === 'running' && completedCount === AGENTS.length

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f0ede8]">
      <Navbar />

      <main className="max-w-4xl mx-auto px-6 pt-24 pb-20">

        {/* ── Header ───────────────────────── */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-1">New Analysis</h1>
          <p className="text-white/40 text-sm">
            {plan === 'free' ? `${limit - used} free ${limit - used === 1 ? 'analysis' : 'analyses'} remaining · ` : ''}
            Describe your idea below and deploy all 6 agents.
          </p>
        </div>

        {/* ── Upgrade banner ──────────────── */}
        {showUpgrade && (
          <div className="mb-6 bg-[#BA7517]/10 border border-[#BA7517]/30 rounded-xl p-4 flex items-center justify-between gap-4">
            <div>
              <p className="text-sm font-semibold text-[#FAC775] mb-0.5">Analysis limit reached</p>
              <p className="text-xs text-white/50">{error}</p>
            </div>
            <Link href="/pricing" className="btn-gradient px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap flex-shrink-0">
              Upgrade →
            </Link>
          </div>
        )}

        {/* ── Input card ──────────────────── */}
        <div className="glass rounded-2xl p-5 mb-6">
          <label className="text-xs font-medium text-white/40 uppercase tracking-widest block mb-3">
            Business Idea
          </label>
          <textarea
            value={idea}
            onChange={e => setIdea(e.target.value)}
            rows={5}
            disabled={phase === 'running'}
            placeholder={'Describe your business idea in detail. Include:\n• What it does and who it serves\n• How it makes money\n• What problem it solves\n• Any initial traction or insights you have\n\nThe more context you give, the sharper the analysis.'}
            className="w-full bg-transparent text-sm text-white/80 placeholder-white/20 resize-none outline-none leading-relaxed"
          />
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5">
            <div className="flex items-center gap-2 flex-wrap">
              {AGENTS.map(a => (
                <span key={a.id} className="text-[10px] px-2 py-0.5 rounded-full border"
                  style={{ borderColor: AGENT_COLORS[a.id].border + '55', color: AGENT_COLORS[a.id].text, background: AGENT_COLORS[a.id].bg }}>
                  {a.abbr}
                </span>
              ))}
              <span className="text-[10px] px-2 py-0.5 rounded-full border border-[#BA7517]/40 text-[#FAC775] bg-[#BA7517]/10">◈ Synthesis</span>
            </div>
            <button
              onClick={runAnalysis}
              disabled={!idea.trim() || phase === 'running' || !canRun}
              className="btn-gradient px-5 py-2.5 rounded-xl text-sm font-semibold disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
            >
              {phase === 'running' ? (
                <span className="flex items-center gap-2">
                  <span className="w-3 h-3 border border-white/40 border-t-white rounded-full animate-spin-slow" />
                  Running...
                </span>
              ) : 'Deploy All Agents →'}
            </button>
          </div>
        </div>

        {/* ── Error ───────────────────────── */}
        {error && !showUpgrade && (
          <div className="mb-4 bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3 text-sm text-red-400">
            {error}
          </div>
        )}

        {/* ── Agent pipeline grid ─────────── */}
        {(phase !== 'idle') && (
          <>
            <p className="text-xs font-medium text-white/30 uppercase tracking-widest mb-3">Agent Pipeline</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
              {AGENTS.map((agent, idx) => {
                const isDone   = !!agentOutputs[agent.id as AgentId]
                const isActive = activeAgentId === agent.id
                const isSelected = selectedAgent === agent.id
                const colors = AGENT_COLORS[agent.id as AgentId]
                const isPending = !isDone && !isActive

                return (
                  <button
                    key={agent.id}
                    onClick={() => isDone && setSelectedAgent(agent.id as AgentId)}
                    disabled={!isDone}
                    className={`agent-card text-left rounded-xl p-4 border transition-all ${
                      isSelected ? 'ring-1' : ''
                    } ${isPending ? 'opacity-30' : ''}`}
                    style={{
                      background: isActive || isDone ? colors.bg : 'rgba(255,255,255,0.02)',
                      borderColor: isDone || isActive ? colors.border + '60' : 'rgba(255,255,255,0.06)',
                      borderLeftColor: isDone || isActive ? colors.border : 'rgba(255,255,255,0.06)',
                      borderLeftWidth: '3px',
                      ringColor: isSelected ? colors.border : undefined,
                    } as React.CSSProperties}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[11px] font-bold font-mono" style={{ color: isDone || isActive ? colors.text : 'rgba(255,255,255,0.3)' }}>
                        {agent.abbr}
                      </span>
                      {isDone  && <span className="text-[10px]" style={{ color: colors.border }}>✓</span>}
                      {isActive && <span className="animate-pulse-dot text-[10px]" style={{ color: colors.border }}>●</span>}
                    </div>
                    <p className="text-[11px] font-semibold text-white/80 mb-1">{agent.label}</p>
                    <p className="text-[10px] text-white/35">{agent.desc}</p>
                  </button>
                )
              })}
            </div>

            {/* Synthesis progress */}
            {isSynthesizing && (
              <div className="glass rounded-xl p-4 mb-4 border border-[#BA7517]/30 bg-[#BA7517]/5 flex items-center gap-3">
                <span className="animate-spin-slow text-[#BA7517] text-lg">◈</span>
                <div>
                  <p className="text-sm font-semibold text-[#FAC775]">Master Synthesizer is compiling your Venture Compass Report...</p>
                  <p className="text-xs text-white/30 mt-0.5">All 6 agents complete. Synthesizing insights.</p>
                </div>
              </div>
            )}
          </>
        )}

        {/* ── Agent output viewer ─────────── */}
        {selectedAgent && agentOutputs[selectedAgent] && (
          <div className="animate-fade-in-up glass rounded-2xl overflow-hidden mb-6"
            style={{ borderColor: AGENT_COLORS[selectedAgent].border + '50', borderWidth: '1px' }}>
            <div className="flex items-center justify-between px-5 py-3.5 border-b"
              style={{ borderColor: AGENT_COLORS[selectedAgent].border + '30', background: AGENT_COLORS[selectedAgent].bg }}>
              <div>
                <span className="text-sm font-bold" style={{ color: AGENT_COLORS[selectedAgent].text }}>
                  {AGENTS.find(a => a.id === selectedAgent)?.label} Report
                </span>
                <span className="text-xs text-white/30 ml-2">Click any completed agent to switch</span>
              </div>
              <button onClick={() => setSelectedAgent(null)} className="text-white/30 hover:text-white/70 text-lg leading-none">×</button>
            </div>
            <div className="agent-output p-5 text-white/75 max-h-[480px] overflow-y-auto">
              {agentOutputs[selectedAgent]}
            </div>
          </div>
        )}

        {/* ── Synthesis report ────────────── */}
        {synthesis && (
          <div className="animate-fade-in-up rounded-2xl overflow-hidden border-2 border-[#BA7517]/40 bg-[#BA7517]/5 mb-6">
            <div className="px-5 py-4 border-b border-[#BA7517]/25 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-[#FAC775] text-lg">◈</span>
                <div>
                  <span className="text-sm font-bold text-[#FAC775]">Venture Compass Report</span>
                  <span className="text-[10px] ml-2 bg-[#BA7517]/20 text-[#FAC775] px-2 py-0.5 rounded-full border border-[#BA7517]/30">Master Synthesis</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {analysisId && (
                  <Link href={`/history?id=${analysisId}`} className="text-xs text-white/30 hover:text-white/60 transition-colors">
                    View saved →
                  </Link>
                )}
                <button
                  onClick={() => navigator.clipboard.writeText(synthesis)}
                  className="text-xs border border-[#BA7517]/30 text-[#FAC775] px-3 py-1.5 rounded-lg hover:bg-[#BA7517]/10 transition-colors"
                >
                  Copy
                </button>
              </div>
            </div>
            <div className="agent-output p-5 text-white/80 max-h-[600px] overflow-y-auto leading-relaxed">
              {synthesis}
            </div>
            <div className="px-5 py-3 border-t border-[#BA7517]/20 flex items-center justify-between">
              <span className="text-xs text-white/25">
                {AGENTS.length} agents · {Object.values(agentOutputs).join('').length.toLocaleString()} chars analyzed
              </span>
              {(plan === 'free' || plan === 'starter') && (
                <Link href="/pricing" className="text-xs text-[#FAC775] hover:text-[#FAC775]/80 transition-colors">
                  Upgrade for unlimited analyses →
                </Link>
              )}
            </div>
          </div>
        )}

        {/* ── Empty state ─────────────────── */}
        {phase === 'idle' && !error && (
          <div className="text-center py-16">
            <div className="text-4xl mb-4 opacity-20">◈</div>
            <p className="text-white/20 text-sm">Your venture analysis will appear here.</p>
          </div>
        )}

      </main>
    </div>
  )
}
