import { NextRequest, NextResponse } from 'next/server'
import { stripe, planFromPriceId } from '@/lib/stripe'
import { updateUserPlan, upsertSubscription, getUserByEmail } from '@/lib/supabase'
import type Stripe from 'stripe'
import type { Plan } from '@/types'

export async function POST(req: NextRequest) {
  const body = await req.text()
  const sig = req.headers.get('stripe-signature')!

  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Webhook error'
    console.error('Stripe webhook signature error:', msg)
    return NextResponse.json({ error: msg }, { status: 400 })
  }

  console.log(`Stripe event: ${event.type}`)

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session
        if (session.mode === 'subscription') {
          const subscription = await stripe.subscriptions.retrieve(session.subscription as string)
          const userEmail = session.metadata?.userEmail
          if (!userEmail) break

          const priceId = subscription.items.data[0].price.id
          const plan = planFromPriceId(priceId) as Plan

          await updateUserPlan(userEmail, plan, session.customer as string)

          const user = await getUserByEmail(userEmail)
          if (user) {
            await upsertSubscription({
              userId: user.id,
              stripeSubscriptionId: subscription.id,
              stripePriceId: priceId,
              plan,
              status: subscription.status,
              currentPeriodEnd: new Date(subscription.current_period_end * 1000),
              cancelAtPeriodEnd: subscription.cancel_at_period_end,
            })
          }
        }
        break
      }

      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription
        const userEmail = subscription.metadata?.userEmail
        if (!userEmail) break

        const priceId = subscription.items.data[0].price.id
        const plan = planFromPriceId(priceId) as Plan

        if (subscription.status === 'active') {
          await updateUserPlan(userEmail, plan)
        } else if (['canceled', 'unpaid', 'past_due'].includes(subscription.status)) {
          await updateUserPlan(userEmail, 'free')
        }

        const user = await getUserByEmail(userEmail)
        if (user) {
          await upsertSubscription({
            userId: user.id,
            stripeSubscriptionId: subscription.id,
            stripePriceId: priceId,
            plan: subscription.status === 'active' ? plan : 'free',
            status: subscription.status,
            currentPeriodEnd: new Date(subscription.current_period_end * 1000),
            cancelAtPeriodEnd: subscription.cancel_at_period_end,
          })
        }
        break
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription
        const userEmail = subscription.metadata?.userEmail
        if (userEmail) {
          await updateUserPlan(userEmail, 'free')
        }
        break
      }

      case 'invoice.payment_failed': {
        // Could send an email here via Resend/SendGrid
        console.log('Payment failed for:', (event.data.object as Stripe.Invoice).customer_email)
        break
      }
    }
  } catch (err) {
    console.error('Webhook handler error:', err)
    return NextResponse.json({ error: 'Webhook handler failed' }, { status: 500 })
  }

  return NextResponse.json({ received: true })
}
