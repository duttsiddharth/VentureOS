import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'
import { createCheckoutSession, createOrRetrieveCustomer } from '@/lib/stripe'
import { getUserByEmail, updateUserPlan } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { priceId } = await req.json()
  if (!priceId) {
    return NextResponse.json({ error: 'priceId required' }, { status: 400 })
  }

  const user = await getUserByEmail(session.user.email)
  if (!user) {
    return NextResponse.json({ error: 'User not found' }, { status: 404 })
  }

  // Create or retrieve Stripe customer
  const customerId = await createOrRetrieveCustomer({
    email: session.user.email,
    name: session.user.name,
    stripeCustomerId: user.stripe_customer_id,
  })

  // Update stripe_customer_id in DB if new
  if (!user.stripe_customer_id) {
    await updateUserPlan(session.user.email, user.plan, customerId)
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL!
  const checkoutUrl = await createCheckoutSession({
    customerId,
    priceId,
    userId: user.id,
    userEmail: session.user.email,
    successUrl: `${appUrl}/dashboard?upgrade=success`,
    cancelUrl: `${appUrl}/pricing?canceled=true`,
  })

  return NextResponse.json({ url: checkoutUrl })
}
