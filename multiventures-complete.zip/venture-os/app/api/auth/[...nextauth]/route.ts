import NextAuth from 'next-auth'
import GoogleProvider from 'next-auth/providers/google'
import type { NextAuthOptions } from 'next-auth'
import { upsertUser, getUserByEmail } from '@/lib/supabase'

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
  ],

  callbacks: {
    async signIn({ user }) {
      if (!user.email) return false
      try {
        // Create or update user in Supabase on every sign-in
        await upsertUser({
          email: user.email,
          name: user.name,
          image: user.image,
        })
        return true
      } catch (err) {
        console.error('SignIn error:', err)
        return false
      }
    },

    async session({ session }) {
      // Enrich session with Supabase user data (plan, usage)
      if (session.user?.email) {
        try {
          const dbUser = await getUserByEmail(session.user.email)
          if (dbUser) {
            session.user = {
              ...session.user,
              id: dbUser.id,
              plan: dbUser.plan,
              analysesUsed: dbUser.analyses_used,
              analysesLimit: dbUser.analyses_limit,
              stripeCustomerId: dbUser.stripe_customer_id,
            } as any
          }
        } catch (err) {
          console.error('Session enrichment error:', err)
        }
      }
      return session
    },
  },

  pages: {
    signIn: '/auth/signin',
    error: '/auth/error',
  },

  session: { strategy: 'jwt', maxAge: 30 * 24 * 60 * 60 }, // 30 days
  secret: process.env.NEXTAUTH_SECRET,
}

const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }
