import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import Anthropic from '@anthropic-ai/sdk'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'
import { AGENTS, SYNTHESIS_SYSTEM_PROMPT } from '@/lib/agents'
import {
  getUserByEmail,
  canRunAnalysis,
  createAnalysis,
  updateAnalysis,
  incrementAnalysesUsed,
} from '@/lib/supabase'
import type { AgentOutputs } from '@/types'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! })

export async function POST(req: NextRequest) {
  // ── Auth check ─────────────────────────────────────────
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { idea } = await req.json()
  if (!idea || typeof idea !== 'string' || idea.trim().length < 20) {
    return NextResponse.json({ error: 'Idea must be at least 20 characters.' }, { status: 400 })
  }

  // ── Usage gate ─────────────────────────────────────────
  const { allowed, reason } = await canRunAnalysis(session.user.email)
  if (!allowed) {
    return NextResponse.json({ error: reason, upgradeRequired: true }, { status: 402 })
  }

  // ── Get user record ────────────────────────────────────
  const user = await getUserByEmail(session.user.email)
  if (!user) {
    return NextResponse.json({ error: 'User not found' }, { status: 404 })
  }

  // ── Create analysis record ─────────────────────────────
  const analysisId = await createAnalysis({ userId: user.id, idea: idea.trim() })

  // ── Stream response back to client ────────────────────
  const encoder = new TextEncoder()
  const stream = new ReadableStream({
    async start(controller) {
      const send = (data: object) => {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`))
      }

      const agentOutputs: AgentOutputs = {}

      try {
        // ── Run each agent sequentially ─────────────────
        for (let i = 0; i < AGENTS.length; i++) {
          const agent = AGENTS[i]
          send({ type: 'agent_start', agentId: agent.id, agentIndex: i })

          // Build context from all prior agents
          const priorContext = Object.entries(agentOutputs)
            .map(([id, txt]) => {
              const a = AGENTS.find(ag => ag.id === id)
              return `=== ${a?.label} Report ===\n${txt}`
            })
            .join('\n\n')

          const userMessage = priorContext
            ? `Business Idea: ${idea.trim()}\n\nPrior Agent Reports:\n\n${priorContext}\n\nNow provide your specialized analysis.`
            : `Business Idea: ${idea.trim()}`

          // Call Anthropic API
          const message = await anthropic.messages.create({
            model: 'claude-sonnet-4-20250514',
            max_tokens: 1500,
            system: agent.prompt,
            messages: [{ role: 'user', content: userMessage }],
          })

          const output = message.content.map(b => ('text' in b ? b.text : '')).join('')
          agentOutputs[agent.id as keyof AgentOutputs] = output

          // Save intermediate progress
          await updateAnalysis(analysisId, { agent_outputs: agentOutputs })

          send({ type: 'agent_complete', agentId: agent.id, output })
        }

        // ── Master synthesis ────────────────────────────
        send({ type: 'synthesis_start' })

        const allReports = AGENTS.map(a => `=== ${a.label} ===\n${agentOutputs[a.id as keyof AgentOutputs]}`).join('\n\n')

        const synthMessage = await anthropic.messages.create({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 2000,
          system: SYNTHESIS_SYSTEM_PROMPT,
          messages: [{
            role: 'user',
            content: `Business Idea: ${idea.trim()}\n\nAll Agent Reports:\n\n${allReports}\n\nNow synthesize the definitive Venture Compass Report.`,
          }],
        })

        const synthesis = synthMessage.content.map(b => ('text' in b ? b.text : '')).join('')

        // ── Persist completed analysis ──────────────────
        await updateAnalysis(analysisId, {
          agent_outputs: agentOutputs,
          synthesis,
          status: 'complete',
        })

        // ── Increment usage counter ─────────────────────
        await incrementAnalysesUsed(session.user!.email!)

        send({ type: 'complete', synthesis, analysisId })
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Unknown error'
        await updateAnalysis(analysisId, { status: 'error' })
        send({ type: 'error', message })
      } finally {
        controller.close()
      }
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    },
  })
}
