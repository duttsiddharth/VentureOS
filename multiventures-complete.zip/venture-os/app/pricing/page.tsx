'use client'
import { useSession } from 'next-auth/react'
import { useSearchParams, useRouter } from 'next/navigation'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import Navbar from '@/components/Navbar'
import { PRICING_TIERS } from '@/lib/stripe'

export default function PricingPage() {
  const { data: session, status } = useSession()
  const searchParams = useSearchParams()
  const router = useRouter()
  const [loading, setLoading] = useState<string | null>(null)
  const [successMsg, setSuccessMsg] = useState('')

  const user = session?.user as any
  const currentPlan: string = user?.plan || 'free'

  useEffect(() => {
    if (searchParams.get('upgrade') === 'success') {
      setSuccessMsg('🎉 Your plan has been upgraded! Welcome to the next level.')
    }
  }, [searchParams])

  async function checkout(priceId: string, planName: string) {
    if (status === 'unauthenticated') {
      router.push(`/auth/signin?plan=${planName}`)
      return
    }
    setLoading(priceId)
    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ priceId }),
      })
      const { url, error } = await res.json()
      if (error) alert(error)
      else window.location.href = url
    } finally {
      setLoading(null)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f0ede8]">
      {session && <Navbar />}

      <main className={`max-w-5xl mx-auto px-6 pb-20 ${session ? 'pt-28' : 'pt-16'}`}>

        {/* Success banner */}
        {successMsg && (
          <div className="mb-8 bg-green-500/10 border border-green-500/20 rounded-xl px-5 py-4 text-sm text-green-400">
            {successMsg}
          </div>
        )}

        {!session && (
          <div className="mb-6 text-center">
            <Link href="/" className="inline-flex items-center gap-2 mb-8">
              <div className="w-8 h-8 rounded-lg bg-[#BA7517] flex items-center justify-center font-bold text-white text-sm">V</div>
              <span className="font-bold">MultiVentures</span>
            </Link>
          </div>
        )}

        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold mb-3">Simple, Honest Pricing</h1>
          <p className="text-white/50">Start free. Upgrade when your ideas multiply.</p>
        </div>

        {/* Current plan notice */}
        {session && currentPlan !== 'free' && (
          <div className="mb-6 glass rounded-xl px-5 py-4 flex items-center justify-between">
            <span className="text-sm text-white/60">
              You are on the <span className="text-[#FAC775] font-semibold">{currentPlan.charAt(0).toUpperCase() + currentPlan.slice(1)}</span> plan
            </span>
            <button
              onClick={async () => {
                const res = await fetch('/api/stripe/portal', { method: 'POST' })
                const { url } = await res.json()
                if (url) window.location.href = url
              }}
              className="text-xs text-white/50 hover:text-white border border-white/10 hover:border-white/30 px-3 py-1.5 rounded-lg transition-colors"
            >
              Manage Billing
            </button>
          </div>
        )}

        {/* Free tier */}
        <div className="glass rounded-2xl p-6 mb-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <span className="font-bold text-lg">Free</span>
              <span className="text-xs bg-white/10 text-white/50 px-2 py-0.5 rounded-full">Forever</span>
              {currentPlan === 'free' && <span className="text-xs text-[#FAC775] border border-[#BA7517]/30 px-2 py-0.5 rounded-full">Current plan</span>}
            </div>
            <p className="text-white/50 text-sm max-w-md">1 complete multi-agent analysis. Experience the full pipeline before committing. No credit card ever required.</p>
          </div>
          <div className="flex items-center gap-4 flex-shrink-0">
            <span className="text-3xl font-bold">$0</span>
            <Link href={session ? '/dashboard' : '/auth/signin'} className="px-5 py-2.5 rounded-xl border border-white/15 text-sm font-medium hover:border-white/35 transition-colors whitespace-nowrap">
              {session ? 'Go to Dashboard' : 'Start Free →'}
            </Link>
          </div>
        </div>

        {/* Paid tiers */}
        <div className="grid md:grid-cols-3 gap-4">
          {PRICING_TIERS.map((tier) => {
            const isCurrent = currentPlan === tier.plan
            const isLoading = loading === tier.priceId

            return (
              <div
                key={tier.plan}
                className={`rounded-2xl p-6 flex flex-col relative ${
                  tier.highlighted
                    ? 'bg-[#BA7517]/8 border-2 border-[#BA7517]/40'
                    : 'glass border border-white/8'
                }`}
              >
                {tier.highlighted && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-[10px] font-bold text-[#FAC775] bg-[#0a0a0a] px-3 py-0.5 rounded-full border border-[#BA7517]/40">
                    MOST POPULAR
                  </div>
                )}

                {isCurrent && (
                  <div className="absolute -top-3 right-4 text-[10px] font-bold text-green-400 bg-[#0a0a0a] px-3 py-0.5 rounded-full border border-green-500/30">
                    CURRENT
                  </div>
                )}

                <div className="mb-5">
                  <div className="text-sm text-white/40 mb-1">{tier.name}</div>
                  <div className="flex items-baseline gap-1 mb-1">
                    <span className="text-4xl font-bold">${tier.price}</span>
                    <span className="text-white/30 text-sm">/month</span>
                  </div>
                  <div className="text-xs text-[#FAC775]">{tier.analyses}</div>
                </div>

                <ul className="space-y-2.5 mb-6 flex-1">
                  {tier.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-xs text-white/55">
                      <span className="text-[#BA7517] mt-0.5 flex-shrink-0">✓</span>
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => !isCurrent && checkout(tier.priceId, tier.plan)}
                  disabled={isCurrent || isLoading}
                  className={`w-full py-3 rounded-xl text-sm font-semibold transition-all ${
                    isCurrent
                      ? 'bg-white/5 text-white/30 cursor-default'
                      : tier.highlighted
                      ? 'btn-gradient'
                      : 'border border-white/15 hover:border-white/30 hover:bg-white/5'
                  }`}
                >
                  {isLoading ? (
                    <span className="flex items-center justify-center gap-2">
                      <span className="w-3 h-3 border border-white/40 border-t-white rounded-full animate-spin-slow" />
                      Redirecting...
                    </span>
                  ) : isCurrent ? 'Current Plan' : tier.cta}
                </button>
              </div>
            )
          })}
        </div>

        {/* Enterprise note */}
        <div className="text-center mt-8 text-sm text-white/30">
          Need a custom plan? <a href="mailto:hello@multiventures.ai" className="text-white/50 hover:text-white transition-colors underline">Contact us</a> for enterprise pricing, annual billing, and custom integrations.
        </div>
      </main>
    </div>
  )
}
