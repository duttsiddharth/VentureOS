'use client'
import { useState, useEffect } from 'react'
import { useSearchParams } from 'next/navigation'
import Navbar from '@/components/Navbar'
import Link from 'next/link'
import type { Analysis } from '@/types'

export default function HistoryPage() {
  const [analyses, setAnalyses]   = useState<Analysis[]>([])
  const [selected, setSelected]   = useState<Analysis | null>(null)
  const [loading, setLoading]     = useState(true)
  const [activeTab, setActiveTab] = useState<string>('synthesis')
  const searchParams = useSearchParams()

  useEffect(() => {
    fetch('/api/history').then(r => r.json()).then(data => {
      setAnalyses(data)
      setLoading(false)

      // If ?id= param, auto-select that analysis
      const id = searchParams.get('id')
      if (id) {
        const found = data.find((a: Analysis) => a.id === id)
        if (found) loadAnalysis(found.id)
      }
    })
  }, [])

  async function loadAnalysis(id: string) {
    const res = await fetch(`/api/history?id=${id}`)
    const data = await res.json()
    setSelected(data)
    setActiveTab('synthesis')
  }

  const AGENT_TABS = [
    { id: 'market',   label: 'Market'   },
    { id: 'strategy', label: 'Strategy' },
    { id: 'finance',  label: 'Finance'  },
    { id: 'growth',   label: 'Growth'   },
    { id: 'ops',      label: 'Ops'      },
    { id: 'risk',     label: 'Risk'     },
    { id: 'synthesis',label: '◈ Report' },
  ]

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f0ede8]">
      <Navbar />

      <main className="max-w-6xl mx-auto px-6 pt-24 pb-20">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold">Analysis History</h1>
          <Link href="/dashboard" className="btn-gradient px-4 py-2 rounded-xl text-sm font-semibold">
            New Analysis →
          </Link>
        </div>

        {loading ? (
          <div className="text-center py-20 text-white/30">Loading history...</div>
        ) : analyses.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-white/30 mb-4">No analyses yet.</p>
            <Link href="/dashboard" className="btn-gradient px-6 py-3 rounded-xl text-sm font-semibold inline-block">
              Run Your First Analysis →
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-6">
            {/* List */}
            <div className="md:col-span-1 space-y-2">
              {analyses.map((a) => (
                <button
                  key={a.id}
                  onClick={() => loadAnalysis(a.id)}
                  className={`w-full text-left glass rounded-xl p-4 border transition-all hover:border-white/20 ${
                    selected?.id === a.id ? 'border-[#BA7517]/40 bg-[#BA7517]/5' : 'border-white/5'
                  }`}
                >
                  <p className="text-sm font-medium text-white/80 line-clamp-2 mb-2">{a.idea}</p>
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                      a.status === 'complete' ? 'bg-green-500/15 text-green-400' : 'bg-white/5 text-white/30'
                    }`}>{a.status}</span>
                    <span className="text-[10px] text-white/25">
                      {new Date(a.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </button>
              ))}
            </div>

            {/* Detail */}
            <div className="md:col-span-2">
              {!selected ? (
                <div className="glass rounded-2xl p-8 text-center text-white/25">
                  Select an analysis to view the full report
                </div>
              ) : (
                <div className="glass rounded-2xl overflow-hidden border border-white/8">
                  {/* Idea header */}
                  <div className="px-5 py-4 border-b border-white/8 bg-white/2">
                    <p className="text-sm font-semibold text-white/80 mb-1 line-clamp-2">{selected.idea}</p>
                    <p className="text-xs text-white/25">{new Date(selected.created_at).toLocaleString()}</p>
                  </div>

                  {/* Tabs */}
                  <div className="flex overflow-x-auto border-b border-white/8 bg-white/2">
                    {AGENT_TABS.map(tab => {
                      const hasContent = tab.id === 'synthesis'
                        ? !!selected.synthesis
                        : !!(selected.agent_outputs as any)?.[tab.id]
                      return (
                        <button
                          key={tab.id}
                          onClick={() => hasContent && setActiveTab(tab.id)}
                          disabled={!hasContent}
                          className={`px-4 py-3 text-xs font-medium whitespace-nowrap border-b-2 transition-colors ${
                            activeTab === tab.id
                              ? 'border-[#BA7517] text-[#FAC775]'
                              : hasContent
                              ? 'border-transparent text-white/40 hover:text-white/70'
                              : 'border-transparent text-white/20 cursor-default'
                          }`}
                        >
                          {tab.label}
                        </button>
                      )
                    })}
                  </div>

                  {/* Content */}
                  <div className="agent-output p-5 text-white/70 max-h-[560px] overflow-y-auto">
                    {activeTab === 'synthesis'
                      ? selected.synthesis || 'Synthesis not available.'
                      : (selected.agent_outputs as any)?.[activeTab] || 'Agent output not available.'
                    }
                  </div>

                  {/* Actions */}
                  <div className="px-5 py-3 border-t border-white/8 flex justify-end gap-3">
                    <button
                      onClick={() => {
                        const content = activeTab === 'synthesis'
                          ? selected.synthesis
                          : (selected.agent_outputs as any)?.[activeTab]
                        if (content) navigator.clipboard.writeText(content)
                      }}
                      className="text-xs text-white/40 hover:text-white/70 border border-white/10 hover:border-white/25 px-3 py-1.5 rounded-lg transition-colors"
                    >
                      Copy
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
