'use client'
import { signIn } from 'next-auth/react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'

export default function SignInPage() {
  const searchParams = useSearchParams()
  const plan = searchParams.get('plan')

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-9 h-9 rounded-xl bg-[#BA7517] flex items-center justify-center font-bold text-white">V</div>
            <span className="font-bold text-lg">VentureOS</span>
          </Link>
          <h1 className="text-2xl font-bold mb-2">
            {plan ? `Upgrade to ${plan.charAt(0).toUpperCase() + plan.slice(1)}` : 'Welcome back'}
          </h1>
          <p className="text-white/50 text-sm">
            {plan ? 'Sign in to complete your upgrade.' : 'Sign in to access your venture intelligence platform.'}
          </p>
        </div>

        {/* Sign-in Card */}
        <div className="glass rounded-2xl p-6 space-y-4">
          <button
            onClick={() => signIn('google', { callbackUrl: plan ? `/pricing?plan=${plan}` : '/dashboard' })}
            className="w-full flex items-center justify-center gap-3 bg-white text-gray-900 rounded-xl py-3.5 px-4 font-semibold text-sm hover:bg-gray-50 transition-colors"
          >
            {/* Google logo SVG */}
            <svg width="18" height="18" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M23.745 12.27c0-.79-.07-1.54-.19-2.27h-11.3v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"/>
              <path fill="#34A853" d="M12.255 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96h-3.98v3.09C3.515 21.3 7.615 24 12.255 24z"/>
              <path fill="#FBBC05" d="M5.525 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62h-3.98a11.86 11.86 0 0 0 0 10.76l3.98-3.09z"/>
              <path fill="#EA4335" d="M12.255 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C18.205 1.19 15.495 0 12.255 0c-4.64 0-8.74 2.7-10.71 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"/>
            </svg>
            Continue with Google
          </button>

          <div className="relative flex items-center gap-3">
            <div className="flex-1 h-px bg-white/10" />
            <span className="text-xs text-white/30">secure sign-in</span>
            <div className="flex-1 h-px bg-white/10" />
          </div>

          <p className="text-xs text-white/30 text-center leading-relaxed">
            By signing in, you agree to our{' '}
            <Link href="/terms" className="text-white/50 hover:text-white transition-colors">Terms of Service</Link>
            {' '}and{' '}
            <Link href="/privacy" className="text-white/50 hover:text-white transition-colors">Privacy Policy</Link>.
          </p>
        </div>

        {/* Free tier note */}
        {!plan && (
          <p className="text-center text-xs text-white/30 mt-6">
            ✓ Free tier includes 1 complete analysis · No credit card required
          </p>
        )}
      </div>
    </div>
  )
}
