import Link from 'next/link'
import { PRICING_TIERS } from '@/lib/stripe'

const AGENT_SHOWCASE = [
  { abbr: 'MK', label: 'Market Oracle',      desc: 'TAM, competitive landscape, customer segments, market timing',   color: '#378ADD' },
  { abbr: 'ST', label: 'Strategy Architect', desc: 'Business model, competitive moat, positioning, strategic bets',   color: '#7F77DD' },
  { abbr: 'FN', label: 'Finance CFO',        desc: 'Unit economics, 3-year projections, pricing, capital plan',       color: '#639922' },
  { abbr: 'GR', label: 'Growth Catalyst',    desc: 'Acquisition channels, launch blueprint, viral loops, brand',     color: '#BA7517' },
  { abbr: 'OP', label: 'Ops Architect',      desc: 'Tech stack, MVP scope, team hiring plan, 12-week roadmap',       color: '#D85A30' },
  { abbr: 'RK', label: 'Risk Guardian',      desc: 'Risk matrix, mitigation playbook, legal checklist, kill shots', color: '#E24B4A' },
]

const STATS = [
  { value: '6',    label: 'Specialized AI Agents' },
  { value: '~8m',  label: 'Full Analysis Time' },
  { value: '10K+', label: 'Words of Intelligence' },
  { value: '$0',   label: 'To Start (Free Tier)' },
]

const FAQS = [
  {
    q: 'How is this different from just asking ChatGPT?',
    a: 'VentureOS runs 6 specialized agents sequentially, each building on the previous one\'s analysis. The Market Oracle informs the Strategy Architect, which informs the CFO — creating a layered, interconnected analysis that\'s far richer than a single prompt. Each agent has deep, role-specific expertise baked into its instructions.',
  },
  {
    q: 'How long does a full analysis take?',
    a: 'Typically 6–10 minutes for the complete pipeline (6 agents + master synthesis). Each agent produces 400–800 words of targeted analysis. The result is a 5,000–8,000 word comprehensive venture blueprint.',
  },
  {
    q: 'What makes a good input?',
    a: 'The richer your description, the sharper the output. Include: what the product does, who the customer is, how you make money, and what problem you solve. A 100–300 word description typically yields the best results.',
  },
  {
    q: 'Is my idea kept private?',
    a: 'Yes. Your ideas and analyses are stored securely in your private account and are never shared, sold, or used to train AI models. You can delete your data at any time.',
  },
  {
    q: 'Can I use this for existing businesses, not just new ideas?',
    a: 'Absolutely. VentureOS works excellently for evaluating pivots, entering new markets, validating a new product line, or stress-testing your current strategy against fresh intelligence.',
  },
  {
    q: 'What is the Agency plan for?',
    a: 'The Agency plan is built for consultants and accelerators who want to run analyses for clients. It includes white-label reports (your branding, not ours), client management, bulk analysis, and API access.',
  },
]

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f0ede8]">

      {/* ── Nav ─────────────────────────────────────── */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/5 bg-[#0a0a0a]/80 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#BA7517] flex items-center justify-center font-bold text-white text-sm">V</div>
            <span className="font-semibold tracking-tight">VentureOS</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm text-white/60">
            <a href="#how-it-works" className="hover:text-white transition-colors">How it works</a>
            <a href="#agents"       className="hover:text-white transition-colors">Agents</a>
            <a href="#pricing"      className="hover:text-white transition-colors">Pricing</a>
            <a href="#faq"          className="hover:text-white transition-colors">FAQ</a>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/signin" className="text-sm text-white/60 hover:text-white transition-colors">Sign in</Link>
            <Link href="/auth/signin" className="btn-gradient text-sm px-4 py-2 rounded-lg">
              Try Free →
            </Link>
          </div>
        </div>
      </nav>

      {/* ── Hero ─────────────────────────────────────── */}
      <section className="pt-32 pb-24 px-6 text-center relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#BA7517]/8 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-[#BA7517]/10 border border-[#BA7517]/25 rounded-full px-4 py-1.5 text-xs text-[#FAC775] mb-8">
            <span className="w-1.5 h-1.5 rounded-full bg-[#BA7517] animate-pulse-dot inline-block" />
            6 AI Agents · Real-Time Analysis · Lifetime Reports
          </div>

          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 leading-none">
            Your business idea,<br />
            <span className="shimmer-text">analyzed by experts.</span>
          </h1>

          <p className="text-lg md:text-xl text-white/50 mb-10 max-w-2xl mx-auto leading-relaxed">
            6 specialized AI agents — Market Oracle, Strategy Architect, Finance CFO, Growth Catalyst, Ops Architect, and Risk Guardian — analyze your idea in sequence and synthesize a definitive venture blueprint.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/auth/signin" className="btn-gradient px-8 py-4 rounded-xl text-base font-semibold w-full sm:w-auto text-center">
              Analyze My Idea — Free →
            </Link>
            <a href="#how-it-works" className="px-8 py-4 rounded-xl text-base text-white/60 hover:text-white border border-white/10 hover:border-white/20 transition-all w-full sm:w-auto text-center">
              See How It Works
            </a>
          </div>

          <p className="mt-5 text-xs text-white/30">No credit card required · 1 free analysis · Upgrade anytime</p>
        </div>

        {/* Stats strip */}
        <div className="relative max-w-3xl mx-auto mt-20 grid grid-cols-2 md:grid-cols-4 gap-px bg-white/5 rounded-2xl overflow-hidden border border-white/5">
          {STATS.map((s) => (
            <div key={s.label} className="bg-[#0f0f0f] px-6 py-5 text-center">
              <div className="text-3xl font-bold text-[#FAC775] mb-1">{s.value}</div>
              <div className="text-xs text-white/40">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── How It Works ─────────────────────────────── */}
      <section id="how-it-works" className="py-24 px-6 border-t border-white/5">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How VentureOS Works</h2>
            <p className="text-white/50 max-w-xl mx-auto">A true multi-agent pipeline where each agent builds on the last, creating compounding intelligence.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { step: '01', title: 'Describe Your Idea', desc: 'Write a description of your business idea — what it does, who it serves, how it makes money. The more detail you give, the sharper the analysis.' },
              { step: '02', title: '6 Agents Deploy', desc: 'Six elite AI agents analyze your idea in sequence. Each agent receives all previous outputs as context, building a progressively richer picture of your opportunity.' },
              { step: '03', title: 'Your Venture Blueprint', desc: 'A Master Synthesizer reads all six reports and generates your Venture Compass Report — a complete, investor-grade analysis with an actionable verdict.' },
            ].map((item) => (
              <div key={item.step} className="glass rounded-2xl p-6">
                <div className="text-[#BA7517] font-mono text-xs mb-4 opacity-60">{item.step}</div>
                <h3 className="text-lg font-semibold mb-3">{item.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Agent Showcase ───────────────────────────── */}
      <section id="agents" className="py-24 px-6 bg-[#0d0d0d]">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Meet Your Advisory Board</h2>
            <p className="text-white/50 max-w-xl mx-auto">Each agent is fine-tuned with the expertise of a world-class professional in their domain.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {AGENT_SHOWCASE.map((agent) => (
              <div key={agent.abbr} className="glass rounded-xl p-5 hover:bg-white/5 transition-colors">
                <div className="flex items-center gap-3 mb-3">
                  <div
                    className="w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold font-mono"
                    style={{ background: agent.color + '22', color: agent.color, border: `1px solid ${agent.color}44` }}
                  >
                    {agent.abbr}
                  </div>
                  <span className="font-semibold text-sm">{agent.label}</span>
                </div>
                <p className="text-white/45 text-xs leading-relaxed">{agent.desc}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 glass rounded-xl p-5 border border-[#BA7517]/20 bg-[#BA7517]/5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold font-mono bg-[#BA7517]/20 text-[#FAC775] border border-[#BA7517]/40">◈</div>
              <span className="font-semibold text-sm text-[#FAC775]">Master Synthesizer</span>
              <span className="text-[10px] bg-[#BA7517]/20 text-[#FAC775] px-2 py-0.5 rounded-full border border-[#BA7517]/30">Final Layer</span>
            </div>
            <p className="text-white/45 text-xs leading-relaxed">Reads all 6 agent reports and synthesizes the definitive Venture Compass Report — Executive Summary, Business at a Glance, Unfair Advantages, Critical Path, Investor Verdict, and your First 3 Moves.</p>
          </div>
        </div>
      </section>

      {/* ── Pricing ──────────────────────────────────── */}
      <section id="pricing" className="py-24 px-6 border-t border-white/5">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Simple, Honest Pricing</h2>
            <p className="text-white/50 max-w-xl mx-auto">Start free. Upgrade when you need more. Cancel anytime.</p>
          </div>

          {/* Free tier */}
          <div className="glass rounded-2xl p-6 mb-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-3 mb-1">
                <span className="font-bold text-lg">Free</span>
                <span className="text-xs bg-white/10 text-white/60 px-2 py-0.5 rounded-full">Forever</span>
              </div>
              <p className="text-white/50 text-sm">1 complete analysis — no credit card needed. Enough to see if VentureOS is right for you.</p>
            </div>
            <div className="flex items-center gap-4 flex-shrink-0">
              <span className="text-2xl font-bold">$0</span>
              <Link href="/auth/signin" className="px-5 py-2.5 rounded-lg border border-white/20 text-sm font-medium hover:border-white/40 transition-colors whitespace-nowrap">
                Start Free →
              </Link>
            </div>
          </div>

          {/* Paid tiers */}
          <div className="grid md:grid-cols-3 gap-4">
            {PRICING_TIERS.map((tier) => (
              <div
                key={tier.plan}
                className={`rounded-2xl p-6 flex flex-col ${tier.highlighted ? 'bg-[#BA7517]/10 border-2 border-[#BA7517]/40' : 'glass'}`}
              >
                {tier.highlighted && (
                  <div className="text-[10px] font-bold text-[#FAC775] bg-[#BA7517]/20 w-fit px-2 py-0.5 rounded-full mb-3 border border-[#BA7517]/30">
                    MOST POPULAR
                  </div>
                )}
                <div className="mb-4">
                  <div className="text-sm text-white/50 mb-1">{tier.name}</div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold">${tier.price}</span>
                    <span className="text-white/40 text-sm">/month</span>
                  </div>
                  <div className="text-xs text-[#FAC775] mt-1">{tier.analyses}</div>
                </div>

                <ul className="space-y-2 mb-6 flex-1">
                  {tier.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-xs text-white/60">
                      <span className="text-[#BA7517] mt-0.5 flex-shrink-0">✓</span>
                      {f}
                    </li>
                  ))}
                </ul>

                <Link
                  href={`/auth/signin?plan=${tier.plan}`}
                  className={`text-center py-3 rounded-xl text-sm font-semibold transition-all ${tier.highlighted ? 'btn-gradient' : 'border border-white/20 hover:border-white/40'}`}
                >
                  {tier.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ──────────────────────────────────────── */}
      <section id="faq" className="py-24 px-6 bg-[#0d0d0d] border-t border-white/5">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-16">Frequently Asked</h2>
          <div className="space-y-6">
            {FAQS.map((faq) => (
              <div key={faq.q} className="border-b border-white/10 pb-6">
                <h3 className="font-semibold mb-2 text-white/90">{faq.q}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────── */}
      <section className="py-24 px-6 border-t border-white/5 text-center">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-4xl font-bold mb-4">Ready to stress-test your idea?</h2>
          <p className="text-white/50 mb-8">Join thousands of founders, consultants, and operators who use VentureOS to make smarter bets.</p>
          <Link href="/auth/signin" className="btn-gradient inline-block px-10 py-4 rounded-xl text-base font-semibold">
            Deploy Your First Analysis — Free →
          </Link>
          <p className="mt-4 text-xs text-white/25">No credit card · Takes 30 seconds to sign up · 1 free analysis included</p>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────────── */}
      <footer className="border-t border-white/5 py-10 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-[#BA7517] flex items-center justify-center font-bold text-white text-xs">V</div>
            <span className="text-sm font-semibold">VentureOS</span>
          </div>
          <div className="flex gap-6 text-xs text-white/30">
            <Link href="/privacy" className="hover:text-white/60 transition-colors">Privacy</Link>
            <Link href="/terms"   className="hover:text-white/60 transition-colors">Terms</Link>
            <a href="mailto:hello@ventureos.ai" className="hover:text-white/60 transition-colors">Contact</a>
          </div>
          <p className="text-xs text-white/25">© {new Date().getFullYear()} VentureOS. Built with ♥ and Claude.</p>
        </div>
      </footer>
    </div>
  )
}
