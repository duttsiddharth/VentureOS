import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { Providers } from './providers'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'VentureOS — AI-Powered Business Intelligence',
  description: '6 specialized AI agents analyze your business idea across market, strategy, finance, growth, operations, and risk — then synthesize a definitive venture blueprint.',
  keywords: ['business analysis', 'AI startup advisor', 'venture intelligence', 'business idea validation'],
  openGraph: {
    title: 'VentureOS — AI-Powered Business Intelligence',
    description: 'Get a full venture analysis in minutes. 6 AI agents. 1 comprehensive report.',
    type: 'website',
    images: [{ url: '/og-image.png', width: 1200, height: 630 }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'VentureOS — 6 AI Agents Analyze Your Business Idea',
    description: 'Market · Strategy · Finance · Growth · Ops · Risk — all in one report.',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
