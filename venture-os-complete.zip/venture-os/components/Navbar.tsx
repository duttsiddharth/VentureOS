'use client'
import { useSession, signOut } from 'next-auth/react'
import Link from 'next/link'
import Image from 'next/image'
import { useState } from 'react'

const PLAN_COLORS: Record<string, string> = {
  free:    'bg-white/10 text-white/50',
  starter: 'bg-blue-500/15 text-blue-300 border border-blue-500/25',
  pro:     'bg-[#BA7517]/15 text-[#FAC775] border border-[#BA7517]/30',
  agency:  'bg-purple-500/15 text-purple-300 border border-purple-500/25',
}

export default function Navbar() {
  const { data: session } = useSession()
  const [menuOpen, setMenuOpen] = useState(false)
  const user = session?.user as any
  const plan: string = user?.plan || 'free'
  const used: number = user?.analysesUsed || 0
  const limit: number = user?.analysesLimit || 1

  async function openBillingPortal() {
    const res = await fetch('/api/stripe/portal', { method: 'POST' })
    const { url } = await res.json()
    if (url) window.location.href = url
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/5 bg-[#0a0a0a]/85 backdrop-blur-xl">
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/dashboard" className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#BA7517] flex items-center justify-center font-bold text-white text-xs">V</div>
          <span className="font-semibold text-sm tracking-tight hidden sm:block">VentureOS</span>
        </Link>

        {/* Nav links */}
        <div className="hidden md:flex items-center gap-6 text-sm text-white/50">
          <Link href="/dashboard" className="hover:text-white transition-colors">New Analysis</Link>
          <Link href="/history"   className="hover:text-white transition-colors">History</Link>
          <Link href="/pricing"   className="hover:text-white transition-colors">Pricing</Link>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-3">
          {/* Usage indicator */}
          {plan !== 'pro' && plan !== 'agency' && (
            <div className="hidden sm:flex items-center gap-2 text-xs text-white/40">
              <div className="w-16 h-1 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-[#BA7517] rounded-full transition-all"
                  style={{ width: `${Math.min((used / limit) * 100, 100)}%` }}
                />
              </div>
              <span>{used}/{limit}</span>
            </div>
          )}

          {/* Plan badge */}
          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full uppercase tracking-wide hidden sm:inline-block ${PLAN_COLORS[plan]}`}>
            {plan}
          </span>

          {/* User avatar */}
          <div className="relative">
            <button onClick={() => setMenuOpen(!menuOpen)} className="flex items-center gap-2">
              {user?.image ? (
                <Image src={user.image} alt={user.name || ''} width={30} height={30} className="rounded-full ring-1 ring-white/10" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-xs font-semibold">
                  {user?.name?.charAt(0) || user?.email?.charAt(0) || '?'}
                </div>
              )}
            </button>

            {/* Dropdown */}
            {menuOpen && (
              <div className="absolute right-0 top-full mt-2 w-52 glass rounded-xl py-1 shadow-2xl border border-white/10 z-50">
                <div className="px-4 py-3 border-b border-white/10">
                  <p className="text-sm font-medium truncate">{user?.name || 'User'}</p>
                  <p className="text-xs text-white/40 truncate">{user?.email}</p>
                </div>
                <Link href="/dashboard" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm text-white/70 hover:text-white hover:bg-white/5 transition-colors">
                  New Analysis
                </Link>
                <Link href="/history" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm text-white/70 hover:text-white hover:bg-white/5 transition-colors">
                  History
                </Link>
                {user?.stripeCustomerId && (
                  <button onClick={() => { setMenuOpen(false); openBillingPortal() }} className="w-full text-left flex items-center gap-2 px-4 py-2.5 text-sm text-white/70 hover:text-white hover:bg-white/5 transition-colors">
                    Manage Billing
                  </button>
                )}
                {plan === 'free' || plan === 'starter' ? (
                  <Link href="/pricing" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm text-[#FAC775] hover:text-[#FAC775]/80 hover:bg-white/5 transition-colors">
                    ↑ Upgrade Plan
                  </Link>
                ) : null}
                <div className="border-t border-white/10 mt-1">
                  <button onClick={() => signOut({ callbackUrl: '/' })} className="w-full text-left px-4 py-2.5 text-sm text-white/40 hover:text-white/70 hover:bg-white/5 transition-colors">
                    Sign out
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}
